# SCLLang


This project has the following structure:

* The file `pom.xml` is the Maven configuration file of the project.
* The directory `src/main/mal` contains the MAL specification `SCLLang.mal`, which is the MAL specification of SCLLang.
* The directory `src/main/resources/icons` contains SVG icons for the assets in SCLLang.
* The directory `src/test/java/org/mal_lang/scllang/test` contains the unit tests of SCLLang.

